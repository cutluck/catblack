//This file is used to build a precompiled header
#include "stdafx.h"