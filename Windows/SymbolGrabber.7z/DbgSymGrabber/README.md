# DbgSymGrabber

This is a tool to download specify Symbol (.pdb) files.  

## Screenshot
![Screenshot](https://raw.githubusercontent.com/quangnh89/DbgSymGrabber/origin/image/screenshot.png)
